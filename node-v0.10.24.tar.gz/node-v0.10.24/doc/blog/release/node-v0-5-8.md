version: 0.5.8
title: Node v0.5.8
author: ryandahl
date: Fri Sep 30 2011 16:47:11 GMT-0700 (PDT)
status: publish
category: release
slug: node-v0-5-8

2011.09.30, Version 0.5.8 (unstable)<ul><li>zlib bindings (isaacs)
<li>Windows supports TTY ANSI escape codes (Bert Belder)
<li>Debugger improvements (Fedor Indutny)
<li>crypto: look up SSL errors with ERR_print_errors() (Ben Noordhuis)
<li>dns callbacks go through MakeCallback now
<li>Raise an error when a malformed package.json file is found. (Ben Leslie)
<li>buffers: handle bad length argument in constructor (Ben Noordhuis)
<li>#1726, unref process.stdout
<li>Doc improvements (Ben Noordhuis, Fedor Indutny, koichik)
<li>Upgrade libuv to fe18438</ul>

Download: <a href="http://nodejs.org/dist/v0.5.8/node-v0.5.8.tar.gz">http://nodejs.org/dist/v0.5.8/node-v0.5.8.tar.gz</a>

Windows Executable: <a href="http://nodejs.org/dist/v0.5.8/node.exe">http://nodejs.org/dist/v0.5.8/node.exe</a>

Website: <a href="http://nodejs.org/docs/v0.5.8/">http://nodejs.org/docs/v0.5.8/</a>

Documentation: <a href="http://nodejs.org/docs/v0.5.8/api/">http://nodejs.org/docs/v0.5.8/api/</a>
