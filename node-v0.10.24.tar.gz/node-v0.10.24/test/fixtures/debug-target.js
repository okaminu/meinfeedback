var a = 0;
a += 1;
a += 2;
a += 3;
