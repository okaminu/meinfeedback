version: 0.5.2
title: Node v0.5.2
author: ryandahl
date: Fri Jul 22 2011 11:40:22 GMT-0700 (PDT)
status: publish
category: release
slug: node-v0-5-2

2011.07.22, Version 0.5.2 (unstable)
<ul><li>libuv improvements; named pipe support
<li>#1242 check for SSL_COMP_get_compression_methods() (Ben Noordhuis)
<li>#1348 remove require.paths (isaacs)
<li>#1349 Delimit NODE_PATH with ; on Windows (isaacs)
<li>#1335 Remove EventEmitter from C++
<li>#1357 Load json files with require() (isaacs)
<li>#1374 fix setting ServerResponse.statusCode in writeHead (Trent Mick)
<li>Fixed: GC was being run too often.
<li>Upgrade V8 to 3.4.14
<li>doc improvements</ul>

Download: <a href="http://nodejs.org/dist/v0.5.2/node-v0.5.2.tar.gz">http://nodejs.org/dist/v0.5.2/node-v0.5.2.tar.gz</a>

Windows Executable: <a href="http://nodejs.org/dist/v0.5.2/node.exe">http://nodejs.org/dist/v0.5.2/node.exe</a>

Website: <a href="http://nodejs.org/dist/v0.5.2/docs/">http://nodejs.org/dist/v0.5.2/docs/</a>

Documentation: <a href="http://nodejs.org/dist/v0.5.2/docs/api">http://nodejs.org/dist/v0.5.2/docs/api</a>
