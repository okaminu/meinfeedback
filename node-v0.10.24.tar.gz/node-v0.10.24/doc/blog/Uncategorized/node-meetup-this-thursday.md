title: Node Meetup this Thursday
author: ryandahl
date: Tue Aug 02 2011 21:37:02 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: node-meetup-this-thursday

<a href="http://nodejs.org/meetup/" title="http://nodejs.org/meetup/ ">http://nodejs.org/meetup/</a>
<a href="http://nodemeetup.eventbrite.com/">http://nodemeetup.eventbrite.com/</a>

Three companies will describe their distributed Node applications. Sign up soon, space is limited!
