version: 0.6.5
title: Node v0.6.5
author: ryandahl
date: Sun Dec 04 2011 00:59:57 GMT-0800 (PST)
status: publish
category: release
slug: node-v0-6-5

2011.12.04, Version 0.6.5 (stable)
<ul><li>npm workaround Windows antivirus software (isaacs)
<li>Upgrade V8 to 3.6.6.11</ul>

Source Code: <a href="http://nodejs.org/dist/v0.6.5/node-v0.6.5.tar.gz">http://nodejs.org/dist/v0.6.5/node-v0.6.5.tar.gz</a>

Windows Installer: <a href="http://nodejs.org/dist/v0.6.5/node-v0.6.5.msi">http://nodejs.org/dist/v0.6.5/node-v0.6.5.msi</a>

Macintosh Installer: <a href="http://nodejs.org/dist/v0.6.5/node-v0.6.5.pkg">http://nodejs.org/dist/v0.6.5/node-v0.6.5.pkg</a>

Website: <a href="http://nodejs.org/docs/v0.6.5/">http://nodejs.org/docs/v0.6.5/</a>

Documentation: <a href="http://nodejs.org/docs/v0.6.5/api/">http://nodejs.org/docs/v0.6.5/api/</a>
