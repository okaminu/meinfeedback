title: Ben Noordhuis's Departure
date: Tue Dec  3 14:13:57 PST 2013
slug: bnoordhuis-departure

As of this past weekend, Ben Noordhuis has decided to step away from
Node.js and libuv, and is no longer acting as a core committer.

Ben has done a tremendous amount of great work in the past. We're sad
to lose the benefit of his continued hard work and expertise, and
extremely grateful for what he has added to Node.js and libuv over the
years.

Many of you already have expressed your opinion regarding recent
drama, and I'd like to ask that you please respect our wishes to let
this issue rest, so that we can all focus on the road forward.

Thanks.
