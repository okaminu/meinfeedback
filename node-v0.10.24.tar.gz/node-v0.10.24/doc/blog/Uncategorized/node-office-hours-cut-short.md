title: Node Office Hours Cut Short
author: ryandahl
date: Thu Apr 28 2011 09:04:35 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: node-office-hours-cut-short

This week office hours are only from 4pm to 6pm. Isaac will be in the Joyent office in SF - everyone else is out of town. Sign up at http://nodeworkup.eventbrite.com/ if you would like to come.

The week after, Thursday May 5th, we will all be at NodeConf in Portland.

Normal office hours resume Thursday May 12th.
